package com.example.uolfoodcourt;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements DishAdapter.OnItemClickListener {

    private ArrayList<Dish> dishes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("UOL Food Court Menu");

        RecyclerView rvMenu = findViewById(R.id.rvMenu);

        dishes = new ArrayList<>();
        dishes.add(new Dish("Chicken Biryani", "Rice",
                "Fragrant basmati rice cooked with spiced chicken, served with raita.",
                "03001234501", 350, R.drawable.biryani));
        dishes.add(new Dish("Zinger Burger", "Fast Food",
                "Crispy fried chicken fillet with lettuce and mayo in a soft bun.",
                "03001234502", 420, R.drawable.zinger_burger));
        dishes.add(new Dish("Chicken Roll Paratha", "Snacks",
                "Tender chicken tikka and chutney rolled in a fresh crispy paratha.",
                "03001234503", 250, R.drawable.paratha_roll));
        dishes.add(new Dish("Club Sandwich", "Fast Food",
                "Triple-layer toasted sandwich with chicken, egg, cheese and veggies.",
                "03001234504", 380, R.drawable.club_sandwich));
        dishes.add(new Dish("Fajita Pizza", "Pizza",
                "Hand-tossed pizza topped with fajita chicken, capsicum and mozzarella.",
                "03001234505", 450, R.drawable.fajita_pizza));
        dishes.add(new Dish("Creamy Chicken Pasta", "Pasta",
                "Penne in a rich white sauce with grilled chicken and herbs.",
                "03001234506", 400, R.drawable.pasta));
        dishes.add(new Dish("French Fries", "Snacks",
                "Golden crispy fries with a sprinkle of salt and ketchup on the side.",
                "03001234507", 180, R.drawable.fries));
        dishes.add(new Dish("Chocolate Shake", "Beverages",
                "Thick chilled milkshake blended with chocolate and ice cream.",
                "03001234508", 300, R.drawable.shake));

        rvMenu.setLayoutManager(new GridLayoutManager(this, 2));

        DishAdapter adapter = new DishAdapter(dishes);
        adapter.setOnItemClickListener(this);
        rvMenu.setAdapter(adapter);
    }

    @Override
    public void onItemClick(int position) {
        Dish dish = dishes.get(position);

        Intent intent = new Intent(MainActivity.this, DishDetailActivity.class);
        intent.putExtra(DishDetailActivity.EXTRA_NAME, dish.getName());
        intent.putExtra(DishDetailActivity.EXTRA_CATEGORY, dish.getCategory());
        intent.putExtra(DishDetailActivity.EXTRA_DESCRIPTION, dish.getDescription());
        intent.putExtra(DishDetailActivity.EXTRA_PHONE, dish.getStallPhone());
        intent.putExtra(DishDetailActivity.EXTRA_PRICE, dish.getPrice());
        intent.putExtra(DishDetailActivity.EXTRA_IMAGE, dish.getImageResId());
        startActivity(intent);
    }
}